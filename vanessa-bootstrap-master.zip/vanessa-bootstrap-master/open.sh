#!/bin/bash

vrunner run --no-wait "$@"