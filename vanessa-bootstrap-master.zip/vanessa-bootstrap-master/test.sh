#!/bin/bash

vrunner vanessa "$@"