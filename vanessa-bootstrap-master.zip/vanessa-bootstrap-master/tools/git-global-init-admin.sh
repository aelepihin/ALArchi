#!/bin/bash

sudo git config --system core.longpaths true
